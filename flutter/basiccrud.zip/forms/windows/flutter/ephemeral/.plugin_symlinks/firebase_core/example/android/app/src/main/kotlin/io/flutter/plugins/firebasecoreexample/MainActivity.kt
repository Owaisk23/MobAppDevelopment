package io.flutter.plugins.firebasecoreexample

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
